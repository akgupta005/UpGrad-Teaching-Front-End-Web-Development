var v=document.getElementById('a')
var s=document.querySelector('h1')
var form=document.getElementById("b")
var table =document.getElementById("c")
 form.style.display="none"
v.addEventListener('click',function(){form.style.display='block'
table.style.display='none'
v.style.display='none'
s.textContent='ADD SUSCRIBER'
})
var add=document.getElementById('add')
add.addEventListener('click',function(){v.style.display='block'
table.style.display='block'
document.getElementById('b').style.display="none"})
