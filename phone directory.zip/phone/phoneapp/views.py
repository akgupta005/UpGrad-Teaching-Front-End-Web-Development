from django.shortcuts import render
from . import forms

# Create your views here.
def f(request):
    if request.method=='POST':
        form=forms.phoneform(request.POST)
        if form.is_valid():
            name=form.cleaned_data['name']
            phone=form.cleaned_data['phone']

    form=forms.phoneform()
    mydict={'form':form,'name':name,'phone':phone}
    return render(request,'phoneapp/home.html',mydict)
