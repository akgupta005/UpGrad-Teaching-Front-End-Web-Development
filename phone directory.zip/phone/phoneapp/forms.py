from django import forms
class phoneform(forms.Form):
    name=forms.CharField(max_length=20)
    phone=forms.IntegerField()
