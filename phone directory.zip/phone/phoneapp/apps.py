from django.apps import AppConfig


class PhoneappConfig(AppConfig):
    name = 'phoneapp'
